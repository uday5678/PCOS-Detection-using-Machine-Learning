from flask import Flask, request, jsonify, render_template, send_file
import pandas as pd
import numpy as np
import pickle
import io
import base64
from datetime import datetime

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image as RLImage
)

# --- constants ---
CSV_PATH = 'CLEAN- PCOS SURVEY SPREADSHEET.csv'
FEATURES = [
    "Age", "Weight", "Height", "Blood_Group", "Cycle_Regularity",
    "Weight_Gain", "Excess_Hair", "Skin_Darkening", "Hair_Loss",
    "Acne", "Fast_Food", "Exercise", "Mood_Swings",
    "Periods_Regular", "Period_Duration"
]
TARGET = "PCOS_Diagnosis"

FEATURE_LABELS = {
    "Age": "Age", "Weight": "Weight (kg)", "Height": "Height (cm)",
    "Blood_Group": "Blood Group", "Cycle_Regularity": "Cycle Regularity",
    "Weight_Gain": "Weight Gain", "Excess_Hair": "Excess Hair Growth",
    "Skin_Darkening": "Skin Darkening", "Hair_Loss": "Hair Loss",
    "Acne": "Acne", "Fast_Food": "Fast Food Consumption", "Exercise": "Exercise",
    "Mood_Swings": "Mood Swings", "Periods_Regular": "Periods Regularity",
    "Period_Duration": "Period Duration (days)"
}

# --- load model + scaler + explainer ---
with open('rf_model.pkl', 'rb') as f:
    rf_model = pickle.load(f)
with open('scaler.pkl', 'rb') as f:
    scaler = pickle.load(f)
with open('explainer.pkl', 'rb') as f:
    explainer = pickle.load(f)

# --- load CSV and align columns exactly like training ---
df = pd.read_csv(CSV_PATH)
df.columns = [
    "Age", "Weight", "Height", "Blood_Group", "Cycle_Regularity",
    "Weight_Gain", "Excess_Hair", "Skin_Darkening", "Hair_Loss",
    "Acne", "Fast_Food", "Exercise", "PCOS_Diagnosis",
    "Mood_Swings", "Periods_Regular", "Period_Duration"
]
df[FEATURES + [TARGET]] = df[FEATURES + [TARGET]].apply(pd.to_numeric, errors='coerce')
df.fillna(0, inplace=True)

app = Flask(__name__)


# ---------------------------------------------------------------------
# Core helpers
# ---------------------------------------------------------------------
def get_shap_contributions(scaled_row, pred_class):
    """Return top positive-contributing features (toward the predicted class)."""
    shap_values = explainer.shap_values(scaled_row)

    # shap_values shape handling across sklearn RF binary classifiers
    if isinstance(shap_values, list):
        sv = shap_values[pred_class][0]
    elif shap_values.ndim == 3:
        sv = shap_values[0, :, pred_class]
    else:
        sv = shap_values[0]

    contributions = list(zip(FEATURES, sv))
    contributions.sort(key=lambda x: abs(x[1]), reverse=True)
    return contributions


def shap_based_recommendations(contributions, pcos_positive, top_n=5):
    recs = []
    top_factors = [c for c in contributions[:top_n] if abs(c[1]) > 1e-4]

    if top_factors:
        recs.append("Top factors influencing this prediction (SHAP analysis):")
        for feat, val in top_factors:
            direction = "increased" if val > 0 else "decreased"
            label = FEATURE_LABELS.get(feat, feat)
            recs.append(f"  • {label} {direction} the likelihood of this result "
                         f"(impact score: {val:+.3f})")
    return recs


def rule_based_recommendations(input_data, pcos_positive=False):
    (age, weight, height, _blood_group, cycle_irregularity, weight_gain,
     excess_hair, skin_darkening, hair_loss, acne, fast_food, exercise,
     mood_swings, periods_regular, period_duration) = input_data

    bmi = weight / ((height / 100) ** 2) if height else 0.0
    recs = []
    if bmi >= 25:
        recs.append("Adopt a balanced diet to manage weight (BMI indicates overweight).")
    if fast_food:
        recs.append("Limit fast food intake to improve hormonal balance.")
    if not exercise:
        recs.append("Add regular physical activity like walking, yoga, or cycling.")
    if cycle_irregularity:
        recs.append("Track menstrual cycles and consider consulting a gynecologist.")
    if mood_swings:
        recs.append("Practice stress reduction techniques like meditation or therapy.")
    if weight_gain:
        recs.append("Monitor diet and consider speaking with a nutritionist.")
    if not periods_regular:
        recs.append("Irregular periods can indicate hormonal imbalance — follow up with a doctor.")

    if pcos_positive:
        recs += [
            "Since the model indicates possible PCOS, please consult a gynecologist for further diagnosis.",
            "Add regular physical activity like yoga or walking to manage PCOS symptoms.",
            "Limit processed foods and sugars to maintain a healthy weight and balance hormones.",
            "Monitor your menstrual cycle closely and keep track of any irregularities."
        ]
    else:
        recs.append("Maintain a balanced diet and exercise routine to keep hormonal health in check.")

    if not recs:
        recs.append("Your lifestyle inputs look great! Keep up the healthy habits.")

    recs += [
        "If you have irregular periods, consider consulting a doctor for further evaluation.",
        "PCOS runs in families — your history suggests getting evaluated regularly.",
        "Consider fertility counseling if facing difficulties conceiving (if relevant).",
        "Oligomenorrhoea can affect fertility — consult a healthcare provider for advice."
    ]
    return recs, bmi


def predict_single(raw_row):
    """raw_row: 1D array-like of length len(FEATURES). Returns dict result."""
    raw = np.array(raw_row, dtype=float).reshape(1, -1)
    scaled = scaler.transform(pd.DataFrame(raw, columns=FEATURES))
    pred = rf_model.predict(scaled)[0]
    proba = rf_model.predict_proba(scaled)[0]
    pcos_positive = int(pred) == 1

    contributions = get_shap_contributions(scaled, int(pred))
    shap_recs = shap_based_recommendations(contributions, pcos_positive)
    rule_recs, bmi = rule_based_recommendations(raw[0], pcos_positive)

    return {
        "prediction": int(pred),
        "probability": float(proba[int(pred)]),
        "bmi": round(bmi, 2),
        "recommendations": rule_recs + shap_recs,
        "top_shap": [{"feature": FEATURE_LABELS.get(f, f), "impact": round(float(v), 4)}
                     for f, v in contributions[:5]]
    }


# ---------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------
@app.route('/')
def index():
    return render_template('index.html')


@app.route('/predict', methods=['POST'])
def predict():
    payload = request.get_json(force=True)
    raw = np.array(payload['data'], dtype=float)
    patient_name = payload.get('name', 'Patient')

    if raw.ndim == 1:
        raw = raw.reshape(1, -1)
    if raw.shape[1] != len(FEATURES):
        return jsonify({'error': f'Expected {len(FEATURES)} features, got {raw.shape[1]}'}), 400

    result = predict_single(raw[0])

    # append new row to dataset with the SAME column order
    new_row = dict(zip(FEATURES, raw[0]))
    new_row[TARGET] = result["prediction"]
    global df
    df = pd.concat([df, pd.DataFrame([new_row])], ignore_index=True)
    df.to_csv(CSV_PATH, index=False)

    result["name"] = patient_name
    result["input"] = dict(zip(FEATURES, raw[0].tolist()))
    return jsonify(result)


@app.route('/bulk_predict', methods=['POST'])
def bulk_predict():
    """Accepts a CSV file (multipart/form-data, field 'file') with columns
    matching FEATURES (Name column optional) and returns predictions for every row."""
    if 'file' not in request.files:
        return jsonify({'error': 'No file uploaded'}), 400

    file = request.files['file']
    try:
        bulk_df = pd.read_csv(file)
    except Exception as e:
        return jsonify({'error': f'Could not read CSV: {e}'}), 400

    missing = [c for c in FEATURES if c not in bulk_df.columns]
    if missing:
        return jsonify({'error': f'CSV missing required columns: {missing}'}), 400

    names = bulk_df['Name'] if 'Name' in bulk_df.columns else [f"Patient {i+1}" for i in range(len(bulk_df))]

    results = []
    for i, row in bulk_df.iterrows():
        raw_row = row[FEATURES].values.astype(float)
        res = predict_single(raw_row)
        results.append({
            "name": str(names[i]) if hasattr(names, '__getitem__') else names[i],
            "prediction": res["prediction"],
            "probability": round(res["probability"], 3),
            "bmi": res["bmi"],
            "top_factors": ", ".join(f"{t['feature']}" for t in res["top_shap"][:3])
        })

    return jsonify({"count": len(results), "results": results})


@app.route('/eda')
def eda():
    """Returns EDA-ready data: class distribution, correlation with target,
    and per-feature min/max/mean for the statistical analysis section."""
    desc = df[FEATURES].describe().T[['min', 'max', 'mean', 'std']]
    stats_dict = {
        feat: {k: float(v) for k, v in desc.loc[feat].items()}
        for feat in FEATURES
    }

    class_counts = df[TARGET].value_counts().to_dict()
    class_dist = {"Negative (0)": int(class_counts.get(0, 0)),
                  "Positive (1)": int(class_counts.get(1, 0))}

    corr = df[FEATURES + [TARGET]].corr()[TARGET].drop(TARGET)
    correlation = {FEATURE_LABELS.get(f, f): round(float(corr[f]), 3) for f in FEATURES}

    age_bins = pd.cut(df["Age"], bins=[0, 15, 20, 25, 30, 35, 40, 100])
    age_dist = age_bins.value_counts().sort_index()
    age_distribution = {str(k): int(v) for k, v in age_dist.items()}

    return jsonify({
        "stats": stats_dict,
        "class_distribution": class_dist,
        "correlation_with_pcos": correlation,
        "age_distribution": age_distribution,
        "total_records": int(len(df))
    })


@app.route('/stats')
def stats():
    desc = df[FEATURES].describe().T[['min', 'max']]
    clean = {feat: {'min': float(desc.loc[feat, 'min']),
                    'max': float(desc.loc[feat, 'max'])}
             for feat in FEATURES}
    return jsonify(clean)


@app.route('/download_report', methods=['POST'])
def download_report():
    """Generates a PDF report for a single patient prediction."""
    payload = request.get_json(force=True)
    name = payload.get('name', 'Patient')
    input_data = payload.get('input', {})
    prediction = payload.get('prediction')
    probability = payload.get('probability', 0)
    bmi = payload.get('bmi', 0)
    recommendations = payload.get('recommendations', [])
    top_shap = payload.get('top_shap', [])

    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4,
                             topMargin=1.5*cm, bottomMargin=1.5*cm)
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle('TitleStyle', parent=styles['Title'],
                                  textColor=colors.HexColor('#6A4C9C'))
    heading_style = ParagraphStyle('HeadingStyle', parent=styles['Heading2'],
                                    textColor=colors.HexColor('#6A4C9C'))
    normal = styles['Normal']

    elements = []
    elements.append(Paragraph("PCOS Detection Report", title_style))
    elements.append(Spacer(1, 0.3*cm))
    elements.append(Paragraph(f"Patient Name: <b>{name}</b>", normal))
    elements.append(Paragraph(f"Report Date: {datetime.now().strftime('%d-%b-%Y %H:%M')}", normal))
    elements.append(Spacer(1, 0.5*cm))

    result_text = "POSITIVE" if prediction == 1 else "NEGATIVE"
    result_color = colors.HexColor('#FF4D9B') if prediction == 1 else colors.HexColor('#8A4FD6')
    elements.append(Paragraph(
        f"<b>PCOS Diagnosis Prediction: <font color='{result_color}'>{result_text}</font></b>"
        f" (confidence: {probability*100:.1f}%)", styles['Heading2']))
    elements.append(Paragraph(f"BMI: {bmi}", normal))
    elements.append(Spacer(1, 0.4*cm))

    # Patient input table
    elements.append(Paragraph("Patient Input Data", heading_style))
    table_data = [["Feature", "Value"]] + [
        [FEATURE_LABELS.get(k, k), str(v)] for k, v in input_data.items()
    ]
    t = Table(table_data, colWidths=[8*cm, 6*cm])
    t.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#F4D1D1')),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
        ('FONTSIZE', (0, 0), (-1, -1), 9),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#FBE1F4')]),
    ]))
    elements.append(t)
    elements.append(Spacer(1, 0.5*cm))

    # SHAP chart
    if top_shap:
        fig, ax = plt.subplots(figsize=(6, 3))
        feats = [t['feature'] for t in top_shap]
        vals = [t['impact'] for t in top_shap]
        bar_colors = ['#FF4D9B' if v > 0 else '#8A4FD6' for v in vals]
        ax.barh(feats, vals, color=bar_colors)
        ax.set_xlabel('SHAP impact on prediction')
        ax.invert_yaxis()
        fig.tight_layout()
        img_buf = io.BytesIO()
        fig.savefig(img_buf, format='png', dpi=150)
        plt.close(fig)
        img_buf.seek(0)
        elements.append(Paragraph("Key Factors (SHAP Analysis)", heading_style))
        elements.append(RLImage(img_buf, width=14*cm, height=7*cm))
        elements.append(Spacer(1, 0.5*cm))

    # Recommendations
    elements.append(Paragraph("Recommendations", heading_style))
    for rec in recommendations:
        elements.append(Paragraph(f"• {rec}", normal))

    elements.append(Spacer(1, 0.6*cm))
    elements.append(Paragraph(
        "<i>Disclaimer: This is an ML-based screening tool and not a substitute "
        "for professional medical diagnosis. Please consult a gynecologist.</i>",
        styles['Italic']))

    doc.build(elements)
    buffer.seek(0)

    safe_name = "".join(c for c in name if c.isalnum() or c in (' ', '_')).strip().replace(' ', '_')
    filename = f"PCOS_Report_{safe_name or 'Patient'}.pdf"

    return send_file(buffer, as_attachment=True, download_name=filename,
                      mimetype='application/pdf')


if __name__ == "__main__":
    app.run(debug=True, use_reloader=False)
