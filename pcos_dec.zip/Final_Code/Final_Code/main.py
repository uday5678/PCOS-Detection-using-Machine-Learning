import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, classification_report
import pickle
import shap

CSV_PATH = 'CLEAN- PCOS SURVEY SPREADSHEET.csv'

FEATURES = [
    "Age", "Weight", "Height", "Blood_Group", "Cycle_Regularity",
    "Weight_Gain", "Excess_Hair", "Skin_Darkening", "Hair_Loss",
    "Acne", "Fast_Food", "Exercise", "Mood_Swings",
    "Periods_Regular", "Period_Duration"
]
TARGET = "PCOS_Diagnosis"

# Load dataset
data = pd.read_csv(CSV_PATH)
data.columns = [
    "Age", "Weight", "Height", "Blood_Group", "Cycle_Regularity",
    "Weight_Gain", "Excess_Hair", "Skin_Darkening", "Hair_Loss",
    "Acne", "Fast_Food", "Exercise", "PCOS_Diagnosis",
    "Mood_Swings", "Periods_Regular", "Period_Duration"
]

# Split into features and label (keep FEATURES order consistent with app.py)
X = data[FEATURES]
y = data[TARGET]

# Standardize features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(
    X_scaled, y, test_size=0.2, random_state=42, stratify=y
)

# Train the model
rf_model = RandomForestClassifier(n_estimators=300, random_state=42)
rf_model.fit(X_train, y_train)

# Quick eval
y_pred = rf_model.predict(X_test)
print(f"Accuracy: {accuracy_score(y_test, y_pred):.4f}")
print(classification_report(y_test, y_pred))

# Build a SHAP TreeExplainer for the RF model (works directly on scaled features)
explainer = shap.TreeExplainer(rf_model)

# Save model, scaler, explainer, and feature order
with open('rf_model.pkl', 'wb') as f:
    pickle.dump(rf_model, f)

with open('scaler.pkl', 'wb') as f:
    pickle.dump(scaler, f)

with open('explainer.pkl', 'wb') as f:
    pickle.dump(explainer, f)

with open('features.pkl', 'wb') as f:
    pickle.dump(FEATURES, f)

print("Model, Scaler, and SHAP Explainer saved.")
